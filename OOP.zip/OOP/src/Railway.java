import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Railway extends JFrame {

    static class Station {
        private String name;
        private double x, y;

        Station(String name, double x, double y) { this.name = name; this.x = x; this.y = y; }

        String getName() { return name; }
        double distanceTo(Station o) { return Math.sqrt(Math.pow(x-o.x,2) + Math.pow(y-o.y,2)); }
        public String toString() { return name; }
    }

    static abstract class Wagon {
        private int number;
        Wagon(int number) { this.number = number; }
        int getNumber() { return number; }
        abstract String getType();
        public String toString() { return "Ваг.№" + number + " (" + getType() + ")"; }
    }

    static class MailWagon       extends Wagon { MailWagon(int n)       { super(n); } String getType() { return "Почтовый"; } }
    static class RestaurantWagon extends Wagon { RestaurantWagon(int n) { super(n); } String getType() { return "Ресторан"; } }
    static class BuffetWagon     extends Wagon { BuffetWagon(int n)     { super(n); } String getType() { return "Буфет";    } }

    static abstract class PassengerWagon extends Wagon {
        private int seats;
        private double pricePerKm;
        private boolean hasTv, hasPhone, canLie;
        private ArrayList<String> passengers = new ArrayList<>();

        PassengerWagon(int num, int seats, double price, boolean tv, boolean phone, boolean canLie) {
            super(num);
            this.seats = seats; this.pricePerKm = price;
            this.hasTv = tv; this.hasPhone = phone; this.canLie = canLie;
        }

        int getSeats()             { return seats; }
        boolean hasTv()            { return hasTv; }
        boolean hasPhone()         { return hasPhone; }
        boolean canLie()           { return canLie; }
        boolean hasFreeSeats()     { return passengers.size() < seats; }
        int getPassengerCount()    { return passengers.size(); }
        void addPassenger(String name) { passengers.add(name); }

        double getTicketPrice(double dist) {
            double p = pricePerKm * dist;
            if (hasTv)    p += 50;
            if (hasPhone) p += 30;
            return p;
        }
    }

    static class SeatWagon extends PassengerWagon {
        SeatWagon(int n, int seats, double price, boolean tv, boolean ph) { super(n, seats, price, tv, ph, false); }
        String getType() { return "Сидячий"; }
    }

    static class PlatsWagon extends PassengerWagon {
        PlatsWagon(int n, int seats, double price, boolean tv, boolean ph) { super(n, seats, price, tv, ph, true); }
        String getType() { return "Плацкартный"; }
    }

    static class CoupeWagon extends PassengerWagon {
        CoupeWagon(int n, int seats, double price, boolean tv, boolean ph) { super(n, seats, price, tv, ph, true); }
        String getType() { return "Купейный"; }
        double getTicketPrice(double dist) { return super.getTicketPrice(dist) + 100; }
    }

    static class Passenger {
        private String name, wagonType, travelDate;
        private boolean needRestaurant, needBuffet, needTv, needPhone;

        Passenger(String name, String wagonType, String date, boolean r, boolean b, boolean tv, boolean ph) {
            this.name = name; this.wagonType = wagonType; this.travelDate = date;
            this.needRestaurant = r; this.needBuffet = b; this.needTv = tv; this.needPhone = ph;
        }

        String getName()          { return name; }
        String getWagonType()     { return wagonType; }
        String getTravelDate()    { return travelDate; }
        boolean needsRestaurant() { return needRestaurant; }
        boolean needsBuffet()     { return needBuffet; }
        boolean needsTv()         { return needTv; }
        boolean needsPhone()      { return needPhone; }
    }

    static class Train {
        private int number;
        private Station from, to;
        private String depTime, arrTime;
        private ArrayList<Wagon> wagons = new ArrayList<>();

        Train(int num, Station from, Station to, String dep, String arr) {
            this.number = num; this.from = from; this.to = to; this.depTime = dep; this.arrTime = arr;
        }

        int getNumber()      { return number; }
        Station getFrom()    { return from; }
        Station getTo()      { return to; }
        String getDepTime()  { return depTime; }
        String getArrTime()  { return arrTime; }
        double getDistance() { return from.distanceTo(to); }

        void addWagon(Wagon w) { wagons.add(w); }
        ArrayList<Wagon> getWagons() { return wagons; }

        ArrayList<PassengerWagon> getPassengerWagons() {
            ArrayList<PassengerWagon> res = new ArrayList<>();
            for (Wagon w : wagons) if (w instanceof PassengerWagon) res.add((PassengerWagon) w);
            return res;
        }

        boolean has(Class<?> cls) {
            for (Wagon w : wagons) if (cls.isInstance(w)) return true;
            return false;
        }

        int getTotalPassengers() {
            int n = 0;
            for (PassengerWagon pw : getPassengerWagons()) n += pw.getPassengerCount();
            return n;
        }

        double getTotalRevenue() {
            double r = 0;
            for (PassengerWagon pw : getPassengerWagons())
                r += pw.getPassengerCount() * pw.getTicketPrice(getDistance());
            return r;
        }

        PassengerWagon findWagon(Passenger p) {
            for (PassengerWagon pw : getPassengerWagons()) {
                if (!pw.hasFreeSeats()) continue;
                if (!pw.getType().equals(p.getWagonType())) continue;
                if (p.needsTv()    && !pw.hasTv())    continue;
                if (p.needsPhone() && !pw.hasPhone()) continue;
                return pw;
            }
            for (PassengerWagon pw : getPassengerWagons())
                if (pw.hasFreeSeats()) return pw;
            return null;
        }

        public String toString() { return "Поезд №" + number + " (" + from + " -> " + to + ")"; }
    }

    private ArrayList<Train>   trains   = new ArrayList<>();
    private ArrayList<Station> stations = new ArrayList<>();
    private ArrayList<String>  refusals = new ArrayList<>();
    private boolean running = false;

    private JTextArea output = new JTextArea();

    Railway() {
        initData();
        buildUI();
    }

    private void initData() {
        Station msk = new Station("Москва", 0, 0);
        Station spb = new Station("СПб",    0, 650);
        Station kzn = new Station("Казань", 820, 0);
        stations.add(msk); stations.add(spb); stations.add(kzn);

        Train t1 = new Train(1, msk, spb, "08:00", "11:30");
        t1.addWagon(new MailWagon(1));
        t1.addWagon(new RestaurantWagon(2));
        t1.addWagon(new SeatWagon(3,  60, 1.2, true,  false));
        t1.addWagon(new PlatsWagon(4, 54, 1.5, false, true));
        t1.addWagon(new CoupeWagon(5, 36, 2.0, true,  true));
        trains.add(t1);

        Train t2 = new Train(2, msk, kzn, "14:00", "21:00");
        t2.addWagon(new MailWagon(1));
        t2.addWagon(new BuffetWagon(2));
        t2.addWagon(new PlatsWagon(3, 54, 1.3, true,  false));
        t2.addWagon(new CoupeWagon(4, 36, 1.8, true,  true));
        trains.add(t2);
    }

    private void buildUI() {
        setTitle("Железная дорога");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5, 5));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));

        JButton btnStart    = new JButton("Запустить");
        JButton btnStop     = new JButton("Остановить");
        JButton btnBuy      = new JButton("Купить билет");
        JButton btnTrains   = new JButton("Поезда");
        JButton btnLoad     = new JButton("Загруженность");
        JButton btnRevenue  = new JButton("Выручка");
        JButton btnRefusals = new JButton("Отказы");
        JButton btnClear    = new JButton("Очистить");

        btnStart   .addActionListener(e -> { running = true;  print("Имитация запущена."); });
        btnStop    .addActionListener(e -> { running = false; print("Имитация остановлена."); });
        btnBuy     .addActionListener(e -> showBuyDialog());
        btnTrains  .addActionListener(e -> showTrains());
        btnLoad    .addActionListener(e -> showLoad());
        btnRevenue .addActionListener(e -> showRevenue());
        btnRefusals.addActionListener(e -> showRefusals());
        btnClear   .addActionListener(e -> output.setText(""));

        btnPanel.add(btnStart); btnPanel.add(btnStop); btnPanel.add(new JSeparator(JSeparator.VERTICAL));
        btnPanel.add(btnBuy); btnPanel.add(btnTrains); btnPanel.add(btnLoad);
        btnPanel.add(btnRevenue); btnPanel.add(btnRefusals); btnPanel.add(btnClear);
        add(btnPanel, BorderLayout.NORTH);

        output.setEditable(false);
        output.setFont(new Font("Monospaced", Font.PLAIN, 13));
        add(new JScrollPane(output), BorderLayout.CENTER);

        print("Добро пожаловать! Нажмите «Запустить», затем «Купить билет».");

        setVisible(true);
    }

    private void showBuyDialog() {
        if (!running) { print("Сначала нажмите «Запустить»!"); return; }

        JTextField fName  = new JTextField("Иванов Иван", 15);
        JTextField fTrain = new JTextField("1", 5);
        JTextField fDate  = new JTextField("01.06.2025", 10);
        JTextField fDest  = new JTextField("СПб", 10);
        JComboBox<String> fType = new JComboBox<>(new String[]{"Сидячий", "Плацкартный", "Купейный"});
        JCheckBox fRest = new JCheckBox("Ресторан");
        JCheckBox fBuf  = new JCheckBox("Буфет");
        JCheckBox fTv   = new JCheckBox("ТВ");
        JCheckBox fPh   = new JCheckBox("Телефон");

        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Имя пассажира:"));  panel.add(fName);
        panel.add(new JLabel("Номер поезда:"));   panel.add(fTrain);
        panel.add(new JLabel("Дата поездки:"));   panel.add(fDate);
        panel.add(new JLabel("Назначение:"));     panel.add(fDest);
        panel.add(new JLabel("Тип вагона:"));     panel.add(fType);
        panel.add(new JLabel("Условия:"));
        JPanel checks = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        checks.add(fRest); checks.add(fBuf); checks.add(fTv); checks.add(fPh);
        panel.add(checks);

        int result = JOptionPane.showConfirmDialog(this, panel, "Купить билет",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return; // нажали Отмена

        String name = fName.getText().trim();
        String date = fDate.getText().trim();
        int trainNum;
        try { trainNum = Integer.parseInt(fTrain.getText().trim()); }
        catch (NumberFormatException ex) { print("Ошибка: номер поезда должен быть числом!"); return; }

        Passenger p = new Passenger(name, (String) fType.getSelectedItem(), date,
                fRest.isSelected(), fBuf.isSelected(), fTv.isSelected(), fPh.isSelected());

        buyTicket(p, trainNum, fDest.getText().trim());
    }

    private void buyTicket(Passenger p, int trainNum, String dest) {
        Train train = findTrain(trainNum);
        if (train == null)
        { refuse(p, "Поезд №" + trainNum + " не найден"); return; }
        if (!train.getTo().getName().equalsIgnoreCase(dest))
        { refuse(p, "Поезд №" + trainNum + " не идёт в " + dest); return; }
        if (p.needsRestaurant() && !train.has(RestaurantWagon.class))
        { refuse(p, "В поезде №" + trainNum + " нет ресторана"); return; }
        if (p.needsBuffet() && !train.has(BuffetWagon.class))
        { refuse(p, "В поезде №" + trainNum + " нет буфета"); return; }

        PassengerWagon wagon = train.findWagon(p);
        if (wagon == null) { refuse(p, "Нет свободных мест в поезде №" + trainNum); return; }

        wagon.addPassenger(p.getName());
        double price = wagon.getTicketPrice(train.getDistance());
        print("БИЛЕТ ПРОДАН: " + p.getName() + " | " + p.getTravelDate() +
                " | " + train + " | " + wagon + " | " + String.format("%.2f", price) + " руб.");
    }

    private Train findTrain(int number) {
        for (Train t : trains) if (t.getNumber() == number) return t;
        return null;
    }

    private void refuse(Passenger p, String reason) {
        refusals.add(p.getName() + " (" + p.getTravelDate() + "): " + reason);
        print("ОТКАЗ: " + reason);
    }

    private void showTrains() {
        print("=== СОСТОЯНИЕ ПОЕЗДОВ ===");
        for (Train t : trains) {
            print(t + " | " + t.getDepTime() + "-" + t.getArrTime() +
                    " | " + String.format("%.0f", t.getDistance()) + " км | Пасс: " + t.getTotalPassengers());
            for (Wagon w : t.getWagons()) {
                if (w instanceof PassengerWagon) {
                    PassengerWagon pw = (PassengerWagon) w;
                    print("  " + pw + " " + pw.getPassengerCount() + "/" + pw.getSeats() +
                            " | Лежать:" + pw.canLie() + " ТВ:" + pw.hasTv() + " Тел:" + pw.hasPhone());
                } else {
                    print("  " + w);
                }
            }
        }
        print("");
    }

    private void showLoad() {
        print("=== ЗАГРУЖЕННОСТЬ ===");
        Class<?>[] types = { SeatWagon.class, PlatsWagon.class, CoupeWagon.class };
        String[]   names = { "Сидячий", "Плацкартный", "Купейный" };
        for (int i = 0; i < types.length; i++) {
            int total = 0, occ = 0;
            for (Train t : trains)
                for (PassengerWagon pw : t.getPassengerWagons())
                    if (types[i].isInstance(pw)) { total += pw.getSeats(); occ += pw.getPassengerCount(); }
            if (total > 0) print(names[i] + ": " + occ + "/" + total + " (" + (100*occ/total) + "%)");
        }
        print("-- По маршрутам:");
        for (Train t : trains) {
            int total = 0, occ = 0;
            for (PassengerWagon pw : t.getPassengerWagons()) { total += pw.getSeats(); occ += pw.getPassengerCount(); }
            int pct = total == 0 ? 0 : 100 * occ / total;
            print(t.getFrom() + " -> " + t.getTo() + ": " + occ + "/" + total + " (" + pct + "%)");
        }
        print("");
    }

    private void showRevenue() {
        print("=== ВЫРУЧКА ===");
        double grandTotal = 0;
        for (Train t : trains) {
            double r = t.getTotalRevenue(); grandTotal += r;
            print("Поезд №" + t.getNumber() + ": " + String.format("%.2f", r) + " руб.");
        }
        print("-- По станциям:");
        for (Station st : stations) {
            double r = 0;
            for (Train t : trains)
                if (t.getFrom().getName().equals(st.getName())) r += t.getTotalRevenue();
            if (r > 0) print(st.getName() + ": " + String.format("%.2f", r) + " руб.");
        }
        print("-- По типам вагонов:");
        Class<?>[] types = { SeatWagon.class, PlatsWagon.class, CoupeWagon.class };
        String[]   names = { "Сидячий", "Плацкартный", "Купейный" };
        for (int i = 0; i < types.length; i++) {
            double r = 0;
            for (Train t : trains)
                for (PassengerWagon pw : t.getPassengerWagons())
                    if (types[i].isInstance(pw)) r += pw.getPassengerCount() * pw.getTicketPrice(t.getDistance());
            print(names[i] + ": " + String.format("%.2f", r) + " руб.");
        }
        print("ИТОГО: " + String.format("%.2f", grandTotal) + " руб.\n");
    }

    private void showRefusals() {
        print("=== ОТКАЗЫ В ПРОДАЖЕ ===");
        if (refusals.isEmpty()) print("Отказов не было.");
        else for (String s : refusals) print(s);
        print("");
    }

    private void print(String s) {
        output.append(s + "\n");
        output.setCaretPosition(output.getDocument().getLength());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Railway::new);
    }
}